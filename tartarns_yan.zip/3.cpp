#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    while(n--) {
        int k;
        cin >> k;
        string s;
        cin >> s;
        int cnt = 0;
        for(int i = 0; i < k-2; i++) {
            if(s[i] == 'y' && s[i+1] == 'a' && s[i+2] == 'n') {
                cnt++;
            }
        }
        cout << cnt << endl;
    }
}