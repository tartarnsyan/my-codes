#include<bits/stdc++.h>
using namespace std;
int n = 0;
int main() {
    int a[10][10], b[10][10];
    for(int i = 0; i < 5; i++) {
        for(int j = 0; j < 7; j++) {
            cin >> a[i][j];
        }
    }
    for(int i = 0; i < 5; i++) {
        for(int j = 0; j < 7; j++) {
            cin >> b[i][j];
            if(a[i][j] + b[i][j] == 0)n++;
        }
    }
    cout << n << endl;
}