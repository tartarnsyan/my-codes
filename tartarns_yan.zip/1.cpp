#include <iostream>
using namespace std;
int dp[104];
int main()
{
   int x;
   cin >> x;
   if(x <= 0)cout << -1;
   else {
      dp[1] = 1;
      dp[2] = 2;
      for(int i = 3; i <= x; i++) {
         dp[i] = dp[i-1] + dp[i-2];
      }
      cout << dp[x];
   }
}
